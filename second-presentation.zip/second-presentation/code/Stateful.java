distinct()
sorted()