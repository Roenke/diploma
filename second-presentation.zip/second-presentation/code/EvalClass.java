private static class Generated extends MagicAccessorImpl {
  public Object eval(Collection<Integer> context) {
    // Вычисление выражения
    // Подготовка результата
  }
}